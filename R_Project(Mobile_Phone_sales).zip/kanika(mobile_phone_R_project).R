# Load required libraries
library(tidyverse)
library(dplyr)
library(ggplot2)

#Load the dataset
mobilephone_sale<-read.csv("E:/kanika/mobilephone sales.csv")
# View the result
View(mobilephone_sale)

#view the first few rows of the dataset
View(head(mobilephone_sale))
View(head(mobilephone_sale,10))

#view the last few rows of the dataset
View(tail(mobilephone_sale))

#Check the structure of dataset
str(mobilephone_sale)

#summary statistics of the dataset
print(summary(mobilephone_sale))

#Check for missing values
colSums(is.na(mobilephone_sale))

# Check for outliers using IQR method for numerical variables
numeric_vars <- mobilephone_sale %>%
  select(where(is.numeric))

#Remove duplicate rows, if any
mobilephone_sale<-mobilephone_sale%>% distinct()

#Remove rows with missing values using na.omit()
mobilephone_sale<-na.omit(mobilephone_sale)

#Find the Average Rating of mobilephone by model
avg_Rating_by_model<-mobilephone_sale%>%
  group_by(Models) %>%
  summarize(avg_Rating=mean(Rating,na.rm=TRUE)) %>%
  arrange(desc(avg_Rating))
# View the result
View(head(avg_Rating_by_model))

#Identify the Most Common mobile offered by brands
most_common_mobile<-mobilephone_sale%>%
  count(Mobile) %>%
  arrange(desc(n)) %>%
  slice(5)
print(most_common_mobile)

#What are the top 5 highest rated mobile?
top_5_highest_rated_mobile<- mobilephone_sale%>%
  select(Mobile,Rating,Selling.Price) %>%
  filter(!is.na(Rating), !is.na(Selling.Price))%>%
  arrange(desc(Rating))
# View the result
View(top_5_highest_rated_mobile)

#Find the top 5 Highest-Brands by mobilephone sales
top_5_highest_brand<-mobilephone_sale%>%
  select(Mobile ,Brands,Selling.Price)%>%
  filter(!is.na(Brands), !is.na(Selling.Price))%>%
  arrange(desc(Brands))%>%
  slice(1:5)
#view the result
View(top_5_highest_brand)

#Find the top 5 Lowest-Brands by mobilephone sales
bottom_5_lowest_brand<-mobilephone_sale%>%
  select(Mobile ,Brands,Selling.Price)%>%
  filter(!is.na(Brands), !is.na(Selling.Price))%>%
  arrange(Brands)%>%
  slice(1:5)
#view the result
View(bottom_5_lowest_brand)

#What is the correlation between Selling price and Original price
correlation <- cor(mobilephone_sale$Selling.Price, 
                   mobilephone_sale$Original.Price, method = "pearson")
print(correlation)

#Analyze the impact of brand on discount percentage of Mobilephone
Brand_impact<-mobilephone_sale %>%
  group_by(Brands)%>%
  summarize(avg_discount.percentage=mean(discount.percentage,na.rm = TRUE))
# View the result
View(Brand_impact)

#Analyze the impact of Model on Selling.Price of Mobilephone
Model_impact<-mobilephone_sale %>%
  group_by(Models)%>%
  summarize(avg_Selling.Price=mean(Selling.Price,na.rm = TRUE))
# View the result
View(Model_impact)

#Analyze the impact of Mobile on Rating of Mobilephone Sales
Mobile_impact<-mobilephone_sale %>%
  group_by(Mobile)%>%
  summarize(avg_Rating=mean(Rating,na.rm = TRUE))
# View the result
View(Mobile_impact)

#univariate Analysis
# Distribution of a numerical variable(eg-Rating)
ggplot(mobilephone_sale, aes(x=Rating)) +
  geom_histogram(binwidth=0.5, fill="darkgreen", 
                 color="green") +
  labs(title="Distribution of Rating",
       x="Rating", y="Count")

# Calculate the count of each brand type
Brand_counts <- mobilephone_sale %>%
  count(Brands) %>%
  arrange(desc(n)) %>%
  slice(1:10)  # Keep only the top 10 Brands
View(Brand_counts)

# Create the bar plot for the top 10 Brands
ggplot(Brand_counts, aes(x = reorder(Brands, n), y = n)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "Top 10 Brands", x = "Brands", y = "Count") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  coord_flip()

# Pie Chart: Distribution of Brands
brand_counts <- as.data.frame(table(mobilephone_sale$Brands))
colnames(brand_counts) <- c("Brand", "Count")

ggplot(brand_counts, aes(x = "", y = Count, fill = Brand)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Distribution of Brands", x = NULL, y = NULL) +
  theme_void()


#Bivariate Analysis

# Calculate the count of each Models and get the top 10
top_model <- mobilephone_sale %>%
  count(Models) %>%
  arrange(desc(n)) %>%
  slice(1:10) %>%
  pull(Models)
View(top_model)

# Filter the data to include only the top 10 brand
filtered_data <- mobilephone_sale %>%
  filter(Models %in% top_model)
View(filtered_data)

# Line Graph: Selling Price vs. Original Price
ggplot(mobilephone_sale, aes(x = Original.Price, y = Selling.Price)) +
  geom_line(color = "blue") +
  labs(title = "Selling Price vs. Original Price", x = "Original Price", y = "Selling Price") +
  theme_minimal()


#Multivariate Analysis
library(GGally)
ggpairs(numeric_vars, aes(color = Brands, alpha = 0.6))


# Linear regression model
model <- lm(Selling.Price ~ Rating + discount.percentage + Brands, data = mobilephone_sale)
summary(model)

# Scatter Plot: Rating vs. Selling Price colored by Brands

ggplot(mobilephone_sale, aes(x = Selling.Price, y = Rating, color = Brands)) +
  geom_point(size = 3, alpha = 0.7) +
  labs(title = "Rating vs. Selling Price by Brands", x = "Selling Price", y = "Rating") +
  theme_minimal()


# Export cleaned dataset
write.csv(data_clean, "mobilephone_sales_cleaned.csv", row.names=FALSE)

